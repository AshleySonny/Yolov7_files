# photoGoogleAndVideo > 2024-09-09 10:22am
https://universe.roboflow.com/arturwork/photogoogleandvideo

Provided by a Roboflow user
License: CC BY 4.0

