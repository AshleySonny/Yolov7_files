# yolov5-airplane > 2024-08-12 11:28am
https://universe.roboflow.com/visdrone-avgsp/yolov5-airplane-nkeai

Provided by a Roboflow user
License: CC BY 4.0

